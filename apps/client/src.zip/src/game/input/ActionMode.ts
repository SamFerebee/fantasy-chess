export type ActionMode = "move" | "attack";
