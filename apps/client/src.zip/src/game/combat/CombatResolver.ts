import type { AttackProfile, Unit } from "../units/UnitTypes";
import { isAdjacent4Way } from "../rules/adjacency";
import { bresenhamLine } from "../util/gridLine";
import { canScoutKnightBypass, getScoutDoubleKnightBlockerTile } from "../combat/scout/ScoutShot";

export type AttackResult =
  | { ok: false; reason: "outOfRange" }
  | { ok: true; killed: boolean; hit: Unit; damageDealt: number; targetHPAfter: number };

function getPrimaryRangeFromAttack(attack: AttackProfile): number {
  switch (attack.kind) {
    case "melee_adjacent":
      return 1;

    case "projectile_blockable_single":
    case "projectile_unblockable_single":
    case "line_hit_all":
      return Math.max(0, attack.range);

    case "pattern_shot":
      return Math.max(0, attack.maxRange);

    case "quake_aoe":
      return 0;
  }
}

export class CombatResolver {
  tryAttack(attacker: Unit, target: Unit, units: Unit[]): AttackResult {
    const atk = attacker.attack;

    // Melee adjacency
    if (atk.kind === "melee_adjacent") {
      if (!isAdjacent4Way(attacker, target)) return { ok: false, reason: "outOfRange" };
      return this.applyDamage(attacker, target);
    }

    // Range gate (Manhattan)
    const range = getPrimaryRangeFromAttack(atk);
    const dist = Math.abs(attacker.x - target.x) + Math.abs(attacker.y - target.y);
    if (dist < 1 || dist > range) return { ok: false, reason: "outOfRange" };

    // Projectile (blockable)
    if (atk.kind === "projectile_blockable_single") {
      // Scout special rules:
      // 1) If aiming a 2x knight and the midpoint landing tile is occupied,
      //    the shot is blocked BY THAT MIDPOINT and should hit that unit.
      // 2) Otherwise, if aiming a valid knight (x1 or x2 with midpoint empty),
      //    the shot hits the intended target ignoring blockers.
      if (attacker.name === "scout") {
        const blockerMid = getScoutDoubleKnightBlockerTile(attacker, { x: target.x, y: target.y }, units);
        if (blockerMid) {
          const hit = units.find((u) => u.x === blockerMid.x && u.y === blockerMid.y) ?? null;
          if (hit) return this.applyDamage(attacker, hit);
        }

        const bypass = canScoutKnightBypass(attacker, { x: target.x, y: target.y }, units);
        if (bypass) return this.applyDamage(attacker, target);
      }

      // Normal behavior: first unit on the line wins
      const hit = firstUnitOnLine(attacker, target, units) ?? target;
      return this.applyDamage(attacker, hit);
    }

    // Projectile (unblockable)
    if (atk.kind === "projectile_unblockable_single") {
      return this.applyDamage(attacker, target);
    }

    return { ok: false, reason: "outOfRange" };
  }

  private applyDamage(attacker: Unit, target: Unit): AttackResult {
    const raw = Math.max(0, attacker.damage);
    const mitigated = Math.max(0, raw - Math.max(0, target.armor));

    const hpAfter = Math.max(0, target.hp - mitigated);
    const killed = hpAfter <= 0;

    return { ok: true, killed, hit: target, damageDealt: mitigated, targetHPAfter: hpAfter };
  }
}

function keyXY(x: number, y: number) {
  return `${x},${y}`;
}

/**
 * Returns the first unit encountered along the straight line from attacker -> target
 * (excluding attacker tile), inclusive of the target tile.
 */
function firstUnitOnLine(attacker: Unit, target: Unit, units: Unit[]): Unit | null {
  const byPos = new Map<string, Unit>();
  for (const u of units) byPos.set(keyXY(u.x, u.y), u);

  const line = bresenhamLine(attacker.x, attacker.y, target.x, target.y);

  for (let i = 1; i < line.length; i++) {
    const p = line[i];
    const u = byPos.get(keyXY(p.x, p.y));
    if (!u) continue;
    if (u.id === attacker.id) continue;
    return u;
  }

  return null;
}
