import "./style.css";
import { createGame } from "./game/Game";

createGame();